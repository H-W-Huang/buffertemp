import numpy as np
import csv

def convert_raw_data_into_array(raw_data_f):
    raw_data = []
    with open(raw_data_f,'r') as f:
        for line in f:
            raw_data.append([s.strip() for s in line.split('\t')])
    data = np.array(raw_data)[1:,1:].transpose()
    data = data.astype('float64')
    return data

def save_npy(filename,npy):
    np.save(npy,filename)


def parse_input(raw_data_f):
    data = convert_raw_data_into_array(raw_data_f)
    np.save(data)








